package com.lcwd.rating.RatingService.controllers;public class RatingController {
}
