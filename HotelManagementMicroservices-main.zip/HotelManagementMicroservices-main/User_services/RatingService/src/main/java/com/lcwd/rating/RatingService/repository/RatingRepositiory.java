package com.lcwd.rating.RatingService.repository;public interface RatingRepositiory {
}
