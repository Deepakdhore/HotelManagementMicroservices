package com.lcwd.rating.RatingService.services.impl;public class RatingServiceImpl {
}
