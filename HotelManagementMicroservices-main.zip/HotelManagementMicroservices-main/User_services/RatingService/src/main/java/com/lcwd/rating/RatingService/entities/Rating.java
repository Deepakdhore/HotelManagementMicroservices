package com.lcwd.rating.RatingService.entities;public class Rating {
}
