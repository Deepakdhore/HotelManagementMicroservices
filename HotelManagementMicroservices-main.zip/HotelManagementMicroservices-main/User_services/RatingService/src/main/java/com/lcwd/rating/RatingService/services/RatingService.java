package com.lcwd.rating.RatingService.services;public interface RatingService {
}
