package com.lcwd.hotel.HotelService.exceptions;public class GlobalExceptionHandler {
}
