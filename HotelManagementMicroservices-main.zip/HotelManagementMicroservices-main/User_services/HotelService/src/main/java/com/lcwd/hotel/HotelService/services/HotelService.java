package com.lcwd.hotel.HotelService.services;public interface HotelService {
}
