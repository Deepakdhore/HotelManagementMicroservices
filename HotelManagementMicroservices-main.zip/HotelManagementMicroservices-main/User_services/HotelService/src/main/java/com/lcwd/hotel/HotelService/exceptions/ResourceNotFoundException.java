package com.lcwd.hotel.HotelService.exceptions;public class ResourceNotFoundException {
}
