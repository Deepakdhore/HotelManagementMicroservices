package com.lcwd.hotel.HotelService.repositories;public interface HotelRepositories {
}
