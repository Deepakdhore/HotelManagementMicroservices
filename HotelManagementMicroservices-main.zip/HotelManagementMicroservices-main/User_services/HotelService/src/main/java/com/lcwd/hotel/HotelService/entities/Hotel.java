package com.lcwd.hotel.HotelService.entities;public class Hotel {
}
