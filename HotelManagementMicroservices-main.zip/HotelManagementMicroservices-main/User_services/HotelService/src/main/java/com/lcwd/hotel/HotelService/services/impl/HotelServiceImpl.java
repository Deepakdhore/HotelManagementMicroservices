package com.lcwd.hotel.HotelService.services.impl;public class HotelServiceImpl {
}
