package com.lcwd.hotel.HotelService.controllers;public class HotelController {
}
